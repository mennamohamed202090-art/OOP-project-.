package entity;

import java.util.Date;

public class Sprint {
    private Date startDate;
    private Date endDate;
    private String objective;

    public Sprint(Date startDate, Date endDate, String objective) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.objective = objective;
    }

    public void addWorkItem(WorkItem item) {
        System.out.println("WorkItem added to sprint: " + item.getTitle());
    }

    public void assignTeam(User user) {
        System.out.println("User " + user.getName() + " added to sprint team");
    }
}

