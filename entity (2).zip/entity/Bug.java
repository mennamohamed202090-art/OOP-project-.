package entity;

public class Bug extends WorkItem {

    public Bug(String id,String title, String description) {
        super(id,title, description);
    }

    public void reportBug() {
        System.out.println("Bug reported: " + title);
    }
}

