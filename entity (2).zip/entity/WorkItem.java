package entity;

public abstract class WorkItem {
    private String id;
    protected String title;
    private String description;
    private String status;
    private User assignedTo;

    public WorkItem(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.status = "New";
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }
    public User getAssignedTo() { return assignedTo; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }

    public void assignTo(User user) {
        this.assignedTo = user;
    }

    public void updateStatus(String newStatus) {
        this.status = newStatus;
    }
}



