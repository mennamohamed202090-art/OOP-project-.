package entity;

import java.util.ArrayList;

public class Epic extends WorkItem {

    private ArrayList<Story> stories = new ArrayList<>();

    public Epic(String id, String title, String description) {
        super(id, title, description);
    }

    public void addStory(Story story) {
        stories.add(story);
    }

    public ArrayList<Story> getStories() {
        return stories;
    }
}
