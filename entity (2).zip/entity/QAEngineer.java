package entity;

public class QAEngineer extends TechnicalStaff {

    public QAEngineer(String id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void testFeature() {
        System.out.println(getUsername() + " tested a feature.");
    }

    public void reportBug() {
        System.out.println(getUsername() + " reported a bug.");
    }

    public void verifyFix() {
        System.out.println(getUsername() + " verified a bug fix.");
    }


}

