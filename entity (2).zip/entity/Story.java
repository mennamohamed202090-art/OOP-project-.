package entity;

import java.util.ArrayList;

public class Story extends WorkItem {

    private ArrayList<Task> subTasks = new ArrayList<>();

    public Story(String id, String title, String description) {
        super(id, title, description);
    }

    public void addTask(Task task) {
        subTasks.add(task);
    }

    public ArrayList<Task> getSubTasks() {
        return subTasks;
    }
}
