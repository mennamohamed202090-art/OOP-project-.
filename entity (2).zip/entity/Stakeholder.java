package entity;

public class Stakeholder extends User {

    public Stakeholder(String id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void createRequest(){
        System.out.println(getUsername()+"Created a new project request.");
    }
    public void viewRequest(){
        System.out.println(getUsername() + "is viewing all high level requests.");
    }
}

