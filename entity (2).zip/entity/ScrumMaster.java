package entity;

public class ScrumMaster extends User {

    public ScrumMaster(String id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void planSprint() {
        System.out.println(getUsername() + " planned the next sprint.");
    }

    public void assignTask() {
        System.out.println(getUsername() + " assigned a task to a team member.");
    }


}

