package entity;
public class Task extends WorkItem {

    public Task(String id,String title, String description) {
        super(id,title, description);
    }

    public void assignDeveloper(User developer) {
        System.out.println("Developer " + developer.getName() + " assigned to task: " + title);
    }
}
