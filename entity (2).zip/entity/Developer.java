package entity;

public class Developer extends TechnicalStaff {

    public Developer(String id, String name, String username, String password) {
        super(id, name, username, password);
    }


    public void fixBug() {
        System.out.println(getUsername() + " fixed a bug.");
    }

    public void implementFeature() {
        System.out.println(getUsername() + " implemented a new feature.");
    }
}
