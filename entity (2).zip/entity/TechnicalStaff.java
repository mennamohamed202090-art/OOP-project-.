package entity;

public abstract class TechnicalStaff extends User {

    public TechnicalStaff(String id, String name, String username, String password) {
        super(id, name, username, password);
    }

    public void updateTaskStatus() {
        System.out.println(getUsername() + " updated a task status.");
    }

    public void reviewCode() {
        System.out.println(getUsername() + " reviewed code.");
    }
}

