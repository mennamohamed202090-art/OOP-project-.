package Database;

import entity.*;

import java.util.ArrayList;

public class Database {

    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<Epic> epics = new ArrayList<>();
    private ArrayList<Story> stories = new ArrayList<>();
    private ArrayList<Task> tasks = new ArrayList<>();
    private ArrayList<Bug> bugs = new ArrayList<>();
    private ArrayList<Sprint> sprints = new ArrayList<>();

    public ArrayList<User> getUsers() { return users; }
    public ArrayList<Epic> getEpics() { return epics; }
    public ArrayList<Story> getStories() { return stories; }
    public ArrayList<Task> getTasks() { return tasks; }
    public ArrayList<Bug> getBugs() { return bugs; }
    public ArrayList<Sprint> getSprints() { return sprints; }

    public void addUser(User user) { users.add(user); }
    public void addEpic(Epic epic) { epics.add(epic); }
    public void addStory(Story story) { stories.add(story); }
    public void addTask(Task task) { tasks.add(task); }
    public void addBug(Bug bug) { bugs.add(bug); }
    public void addSprint(Sprint sprint) { sprints.add(sprint); }

    public void printSummary() {
        System.out.println("Users: " + users.size());
        System.out.println("Epics: " + epics.size());
        System.out.println("Stories: " + stories.size());
        System.out.println("Tasks: " + tasks.size());
        System.out.println("Bugs: " + bugs.size());
        System.out.println("Sprints: " + sprints.size());
    }
}

